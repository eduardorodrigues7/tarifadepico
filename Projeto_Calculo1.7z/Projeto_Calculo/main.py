from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Literal
import sympy as sp
import pandas as pd
from pathlib import Path


app = FastAPI(title="API - Otimização Tarifa de Pico")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


DEMAND_MODELS = {
    "linear": {
        "descr": "Linear: q(p) = a - b p",
        "formula_latex": r"q(p) = a - b p",
        "params": {
            "a": "Demanda máxima / intercepto",
            "b": "Inclinação da reta"
        }
    },
    "exponential": {
        "descr": "Exponencial: q(p) = a e^{-b p}",
        "formula_latex": r"q(p) = a e^{-b p}",
        "params": {
            "a": "Escala da demanda",
            "b": "Taxa de decaimento"
        }
    },
    "power": {
        "descr": "Potência: q(p) = a p^{-b}",
        "formula_latex": r"q(p) = a p^{-b}",
        "params": {
            "a": "Escala da demanda",
            "b": "Elasticidade"
        }
    },
    "logarithmic": {
        "descr": "Logarítmico: q(p) = a - b ln(p)",
        "formula_latex": r"q(p) = a - b \ln(p)",
        "params": {
            "a": "Intercepto",
            "b": "Sensibilidade logarítmica"
        }
    }
}


class InputData(BaseModel):
    model: Literal["linear", "exponential", "power", "logarithmic"]
    a: float = Field(..., gt=0, description="Parâmetro a")
    b: float = Field(..., gt=0, description="Parâmetro b")
    Cf: float = Field(..., ge=0, description="Custo fixo Cf")
    c: float = Field(..., ge=0, description="Custo marginal c")


p = sp.symbols("p", real=True)

def build_q_symbolic(model: str, a_val: float, b_val: float):
    a_sym, b_sym = sp.symbols("a b", positive=True)

    if model == "linear":
        q_expr = a_sym - b_sym * p

    elif model == "exponential":
        q_expr = a_sym * sp.exp(-b_sym * p)

    elif model == "power":
        q_expr = a_sym * p ** (-b_sym)

    elif model == "logarithmic":
        q_expr = a_sym - b_sym * sp.log(p)

    else:
        raise ValueError("Modelo não suportado.")

    return q_expr.subs({a_sym: a_val, b_sym: b_val})


def profit_expression(q_expr, Cf: float, c: float):
    return p * q_expr - (Cf + c * q_expr)


def safely_solve_first_order(expr):
    dLdp = sp.diff(expr, p)

    try:
        sol = sp.solve(dLdp, p)
        for s in sol:
            s_val = sp.N(s)
            if s_val.is_real:
                s_float = float(s_val)
                if s_float > 0:
                    return s_float
    except Exception:
        pass

    guesses = [0.05, 0.1, 0.5, 1, 2, 5, 10, 20, 50, 100, 200]
    for g in guesses:
        try:
            root = sp.nsolve(dLdp, g)
            rootf = float(root)
            if rootf > 0:
                return rootf
        except Exception:
            continue

    return None


@app.get("/options")
def options():
    return DEMAND_MODELS


@app.post("/otimizar")
def otimizar(data: InputData):
    try:
        model = data.model
        a = data.a
        b = data.b
        Cf = data.Cf
        c = data.c

        # demanda q(p)
        q_sym = build_q_symbolic(model, a, b)

        # lucro L(p)
        L = profit_expression(q_sym, Cf, c)

        # achar p* 
        p_star = safely_solve_first_order(L)

        if p_star is None:
            return {
                "erro": (
                    "Não foi possível encontrar um ponto ótimo p*. "
                    "Verifique se os parâmetros geram um máximo viável."
                ),
                "expressao_L": sp.latex(L),
                "expressao_q": sp.latex(q_sym)
            }

        if p_star <= 0:
            return {
                "erro": (
                    f"Ponto ótimo inválido: p* = {p_star:.4f} ≤ 0. "
                    "Preço deve ser positivo."
                ),
                "expressao_L": sp.latex(L),
                "expressao_q": sp.latex(q_sym)
            }

        # domínio linear
        if model == "linear":
            p_max = a / b
            if p_star > p_max:
                return {
                    "erro": (
                        f"O ponto ótimo matemático p* = {p_star:.4f} está fora do domínio econômico. "
                        f"No modelo linear, p deve satisfazer 0 < p ≤ {p_max:.4f}. "
                        "Caso contrário, a demanda fica negativa."
                    ),
                    "expressao_L": sp.latex(L),
                    "expressao_q": sp.latex(q_sym),
                    "p_max": p_max
                }

        q_star = float(sp.N(q_sym.subs(p, p_star)))

        if q_star < 0:
            return {
                "erro": (
                    f"Demanda inviável: q(p*) = {q_star:.4f} < 0. "
                    "O ponto ótimo matemático não é viável economicamente para esses parâmetros."
                ),
                "expressao_L": sp.latex(L),
                "expressao_q": sp.latex(q_sym),
                "p_star": p_star
            }

        if q_star < 1e-6:
            return {
                "erro": (
                    "A demanda ótima é praticamente zero. "
                    "Isso indica que não há operação economicamente relevante com esses parâmetros."
                ),
                "expressao_L": sp.latex(L),
                "expressao_q": sp.latex(q_sym),
                "p_star": p_star
            }

        # lucro 
        lucro = float(sp.N(L.subs(p, p_star)))

        return {
            "p_opt": round(p_star, 4),
            "q_opt": round(q_star, 4),
            "lucro_opt": round(lucro, 4),
            "expressao_L": sp.latex(L),
            "expressao_q": sp.latex(q_sym),
            "exp_derivada": sp.latex(sp.diff(L, p))
        }

    except Exception as e:
        # Nunca derruba a API: retorna erro em JSON
        return {"erro": f"Erro interno na otimização: {str(e)}"}

BASE_DIR = Path(__file__).resolve().parent
CSV_PATH = BASE_DIR / "CURVA_CARGA_2024.csv"

def process_load_data(file_path: Path = CSV_PATH):
    """
    Lê o CSV, calcula a carga total do sistema e retorna as médias horárias.
    """
    try:
        df = pd.read_csv(file_path, sep=';')
        df["din_instante"] = pd.to_datetime(df["din_instante"])

       
        df_total = df.groupby("din_instante")["val_cargaenergiahomwmed"].sum().reset_index()
        df_total.rename(columns={"val_cargaenergiahomwmed": "total_carga_mw"}, inplace=True)

        
        df_total["hora"] = df_total["din_instante"].dt.hour

        df_hourly_avg = df_total.groupby("hora")["total_carga_mw"].mean().reset_index()
        df_hourly_avg.rename(columns={"hora": "Hora", "total_carga_mw": "Demanda_Media_MW"}, inplace=True)

        dados_horarios = df_hourly_avg.to_dict(orient="records")

        pico = df_hourly_avg.loc[df_hourly_avg["Demanda_Media_MW"].idxmax()]
        minimo = df_hourly_avg.loc[df_hourly_avg["Demanda_Media_MW"].idxmin()]

        return {
            "dados_horarios": dados_horarios,
            "pico_info": {
                "hora": int(pico["Hora"]),
                "demanda": f"{pico['Demanda_Media_MW']:.2f} MW"
            },
            "minimo_info": {
                "hora": int(minimo["Hora"]),
                "demanda": f"{minimo['Demanda_Media_MW']:.2f} MW"
            },
            "status": "sucesso"
        }

    except FileNotFoundError:
        return {"status": "erro", "mensagem": f"Arquivo CSV não encontrado em: {file_path}"}

    except Exception as e:
        return {"status": "erro", "mensagem": f"Erro no processamento: {str(e)}"}




@app.get("/dados-carga")
def get_dados_carga():
    return process_load_data()
